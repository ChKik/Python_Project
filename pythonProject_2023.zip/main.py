import csv
import sys

import requests
import matplotlib.pyplot as plt
import numpy as np
import pyodbc
import tkinter as tk
#import mysql.connector
from PIL import Image, ImageTk
from datetime import datetime, timedelta


# sunartisi poy tha ftiaksei ola to copies twn values se 1-D listes

def ListCreation(dataarg, number, DataRowNumber, listacopy):
    if listacopy == ('Value' or 'Cumulative'):
        for y in range(1, DataRowNumber):
            listacopy.append(int(dataarg[y][number]))
    else:
        for y in range(1, DataRowNumber):
            listacopy.append(dataarg[y][number])


def button_clicked(choice):
    if choice == 1:
        ValueByMonth(ValueList, DateList, Datalistlength, MeasureList)
    elif choice == 2:
        ValueByCountry(ValueList, CountryList, Datalistlength, MeasureList)
    elif choice == 3:
        ValueByTransport(ValueList, Transport_ModeList, Datalistlength, MeasureList)
    elif choice == 4:
        ValueByWeek(ValueList, WeekList, Datalistlength, MeasureList)
    elif choice == 5:
        ValueByMerchandise(ValueList, CommodityList, Datalistlength, MeasureList)
    elif choice == 6:
        exit(0)
    elif choice == 7:
        largestrevenue5months(CumulativeList, DateList, Datalistlength)
    elif choice == 8:
        largestrevenuebyproduct(CumulativeList, CommodityList, Datalistlength, CountryList)
    else:
        print("Something went wrong!")
        exit(0)


# tzirosmonth=[month,value$,valueTONNES]
def ValueByMonth(datavalue, datamonth, DataRowNumber, MeasureList):
    tzirosmonthdollar = [['January ', 0], ['February', 0], ['March', 0], ['April', 0], ['May', 0], ['June', 0],
                         ['July', 0], ['August', 0], ['September', 0], ['October', 0], ['November', 0], ['December', 0]]

    tzirosmonthtonnes = [['January ', 0], ['February', 0], ['March', 0], ['April', 0], ['May', 0], ['June', 0],
                         ['July', 0], ['August', 0], ['September', 0], ['October', 0], ['November', 0], ['December', 0]]
    TempString = ''
    MonthNum = list()

    # tha pairnei ena string toy mhna kai analoga ton mina tha pigainei na vazei to poso ekei pera me ena switch
    for i in range(DataRowNumber - 1):
        TempString = datamonth[i]
        MonthNum = TempString.split("/")  # einai kommatia string mesa se list

        match int(MonthNum[1]):  # pairnei to deutero noymero anamesa sta / / diladi ton arithmo toy mina
            case 1:
                if MeasureList[i] == '$':
                    tzirosmonthdollar[0][1] += datavalue[i]
                else:
                    tzirosmonthtonnes[0][1] += datavalue[i]
            case 2:
                if MeasureList[i] == '$':
                    tzirosmonthdollar[1][1] += datavalue[i]
                else:
                    tzirosmonthtonnes[1][1] += datavalue[i]
            case 3:
                if MeasureList[i] == '$':
                    tzirosmonthdollar[2][1] += datavalue[i]
                else:
                    tzirosmonthtonnes[2][1] += datavalue[i]
            case 4:
                if MeasureList[i] == '$':
                    tzirosmonthdollar[3][1] += datavalue[i]
                else:
                    tzirosmonthtonnes[3][1] += datavalue[i]
            case 5:
                if MeasureList[i] == '$':
                    tzirosmonthdollar[4][1] += datavalue[i]
                else:
                    tzirosmonthtonnes[4][1] += datavalue[i]
            case 6:
                if MeasureList[i] == '$':
                    tzirosmonthdollar[5][1] += datavalue[i]
                else:
                    tzirosmonthtonnes[5][1] += datavalue[i]
            case 7:
                if MeasureList[i] == '$':
                    tzirosmonthdollar[6][1] += datavalue[i]
                else:
                    tzirosmonthtonnes[6][1] += datavalue[i]
            case 8:
                if MeasureList[i] == '$':
                    tzirosmonthdollar[7][1] += datavalue[i]
                else:
                    tzirosmonthtonnes[7][1] += datavalue[i]
            case 9:
                if MeasureList[i] == '$':
                    tzirosmonthdollar[8][1] += datavalue[i]
                else:
                    tzirosmonthtonnes[8][1] += datavalue[i]
            case 10:
                if MeasureList[i] == '$':
                    tzirosmonthdollar[9][1] += datavalue[i]
                else:
                    tzirosmonthtonnes[9][1] += datavalue[i]
            case 11:
                if MeasureList[i] == '$':
                    tzirosmonthdollar[10][1] += datavalue[i]
                else:
                    tzirosmonthtonnes[10][1] += datavalue[i]
            case 12:
                if MeasureList[i] == '$':
                    tzirosmonthdollar[11][1] += datavalue[i]
                else:
                    tzirosmonthtonnes[11][1] += datavalue[i]
            case default:
                print("Something went wrong!")
    # gia to plot
    ydollar = [tzirosmonthdollar[0][1], tzirosmonthdollar[1][1], tzirosmonthdollar[2][1], tzirosmonthdollar[3][1],
               tzirosmonthdollar[4][1],
               tzirosmonthdollar[5][1], tzirosmonthdollar[6][1], tzirosmonthdollar[7][1], tzirosmonthdollar[8][1],
               tzirosmonthdollar[9][1], tzirosmonthdollar[10][1], tzirosmonthdollar[11][1]]

    ytonnes = [tzirosmonthtonnes[0][1], tzirosmonthtonnes[1][1], tzirosmonthtonnes[2][1], tzirosmonthtonnes[3][1],
               tzirosmonthtonnes[4][1],
               tzirosmonthtonnes[5][1], tzirosmonthtonnes[6][1], tzirosmonthtonnes[7][1], tzirosmonthtonnes[8][1],
               tzirosmonthtonnes[9][1], tzirosmonthtonnes[10][1], tzirosmonthtonnes[11][1]]

    x_groups = ['Jan', 'Feb', 'March', 'April', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct',
                'Nov', 'Dec']
    # ftiaxnw 2 subplots poy tha mpoyn sto idio figure telika
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(18, 8))

    ax1.bar(x_groups, ydollar, color='blue', width=0.35)
    ax1.set_xlabel("Months")
    ax1.set_ylabel("$")
    ax1.set_title("Total Value per Month in Dollars")

    ax2.bar(x_groups, ytonnes, color='red', width=0.35)
    ax2.set_xlabel("Months")
    ax2.set_ylabel("Tonnes")
    ax2.set_title("Total Value per Month in Tonnes")

    plt.show()
    """""
    conn = mysql.connector.connect(
        host = "localhost",
        user = "root",
        password = "rootpa$$1234",
        database = "pythonproject"
    )
    cursor = conn.cursor()

    cursor.execute('''CREATE TABLE ValueByMonthDollar(month TEXT,dollar INTEGER)''')
    cursor.execute('''CREATE TABLE ValueByMonthTonnes(month TEXT,tonnes INTEGER)''')

    for x in tzirosmonthdollar:
        cursor.execute("INSERT INTO ValueByMonthDollar VALUES (?, ?)", x)

    for x in tzirosmonthtonnes:
        cursor.execute("INSERT INTO ValueByMonthTonnes VALUES (?, ?)", x)

        conn.commit()
        conn.close()
    """""

def ValueByTransport(datavalue, datatransport, datarowsnumber, measurelist):
    transportlist = set(datatransport)  # monadika ids twn countries stin uniquecountries
    uniquetransport = (list(transportlist))

    transportcount = len(uniquetransport)
    transportvaluearray = [[0 for _ in range(2)] for _ in
                           range(transportcount)]

    for i in range(datarowsnumber - 1):
        for k in range(transportcount):
            if uniquetransport[k] == datatransport[i]:  # vriskei tin xwra kai to noumero tis stin lista uniquecountries
                if measurelist[i] == '$':
                    transportvaluearray[k][0] += datavalue[i]
                else:
                    transportvaluearray[k][1] += datavalue[i]

    labels = uniquetransport

    values1 = [transportvaluearray[k][0] for k in range(transportcount)]
    values2 = [transportvaluearray[k][1] for k in range(transportcount)]

    plt.figure()
    bar1 = plt.bar(labels, values1, color='red')
    plt.title('$ USD')

    plt.figure()
    bar2 = plt.bar(labels, values2, color='blue')
    plt.title('Tonnes')

    plt.legend([bar1, bar2], ['$', 'Tonnes'], loc='upper left')

    # gia kapoio logo sto idio plot den fainontai kai ta duo bar opote anagkastika ftiaxnw 2 figures
    plt.show()


def ValueByWeek(datavalue, dataweek, datarowsnumber, measurelist):
    weeklabels = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']

    weekvaluelist = [[0 for _ in range(2)] for _ in
                     range(7)]
    i = 0

    for v in dataweek:
        match str(v):   #pairnei to string kathe fora kai to sugkrinei me kapoio case
            case 'Sunday':
                if measurelist[i] == '$':
                    weekvaluelist[0][0] += datavalue[i]
                    i = i + 1
                else:
                    weekvaluelist[0][1] += datavalue[i]
                    i = i + 1
            case 'Monday':
                if measurelist[i] == '$':
                    weekvaluelist[1][0] += datavalue[i]
                    i = i + 1
                else:
                    weekvaluelist[1][1] += datavalue[i]
                    i = i + 1
            case 'Tuesday':
                if measurelist[i] == '$':
                    weekvaluelist[2][0] += datavalue[i]
                    i = i + 1
                else:
                    weekvaluelist[2][1] += datavalue[i]
                    i = i + 1
            case 'Wednesday':
                if measurelist[i] == '$':
                    weekvaluelist[3][0] += datavalue[i]
                    i += 1
                else:
                    weekvaluelist[3][1] += datavalue[i]
            case 'Thursday':
                if measurelist[i] == '$':
                    weekvaluelist[4][0] += datavalue[i]
                    i = i + 1
                else:
                    weekvaluelist[4][1] += datavalue[i]
                    i = i + 1
            case 'Friday':
                if measurelist[i] == '$':
                    weekvaluelist[5][0] += datavalue[i]
                    i += 1
                else:
                    weekvaluelist[5][1] += datavalue[i]
            case 'Saturday':
                if measurelist[i] == '$':
                    weekvaluelist[6][0] += datavalue[i]
                    i = i + 1
                else:
                    weekvaluelist[6][1] += datavalue[i]
                    i = i + 1
            case default:
                print("Something went wrong!")
                break

    labels = weeklabels

    values1 = [weekvaluelist[k][0] for k in range(7)]
    values2 = [weekvaluelist[k][1] for k in range(7)]

    plt.figure()
    bar1 = plt.bar(labels, values1, color='red', width=0.35)
    plt.title('$ USD by day of the week')

    plt.figure()
    bar2 = plt.bar(labels, values2, color='blue', width=0.35)
    plt.title('Tonnes by day of the week')

    plt.show()


def ValueByMerchandise(datavalue, datamerchandise, datarowsnumber, measurelist):
    merchendiselist = set(datamerchandise)  # monadika ids twn countries stin merchendise
    uniquecommodity = (list(merchendiselist))

    merchendisecount = len(uniquecommodity)
    merchendisevaluelist = [[0 for _ in range(2)] for _ in
                            range(merchendisecount)]

    for i in range(datarowsnumber - 1):
        for k in range(merchendisecount):
            if uniquecommodity[k] == datamerchandise[i]:  # vriskei tin xwra kai to noumero tis stin lista datamerchndise
                if measurelist[i] == '$':
                    merchendisevaluelist[k][0] += datavalue[i]
                else:
                    merchendisevaluelist[k][1] += datavalue[i]

    labels = uniquecommodity

    values1 = [merchendisevaluelist[k][0] for k in range(merchendisecount)]
    values2 = [merchendisevaluelist[k][1] for k in range(merchendisecount)]

    plt.figure()
    bar1 = plt.bar(labels, values1, color='red', width=0.1)
    plt.title('$ USD in Commodities')

    plt.figure()
    bar2 = plt.bar(labels, values2, color='blue', width=0.1)
    plt.title('Tonnes in Commodities')

    # gia kapoio logo sto idio plot den fainontai kai ta duo bar opote anagkastika ftiaxnw 2 figures
    plt.show()


def largestrevenue5months(cumulativevalue, datevalue, rownumber):  # tha ypothesw oti oi mhnes einai oloi 30 meres
    final_date_list = list()
    limit_month = 0
    inputdate = str(datevalue[0])
    flag = 0
    aksia = 0
    telikhmerominia = datevalue[rownumber - 2]
    datelimit = datetime.strptime(telikhmerominia, "%d/%m/%Y")
    starting_date = datetime.strptime(inputdate, "%d/%m/%Y")  # arxikes hmerominies se date format
    for j in range(0, rownumber - 1):
        telikh_arxikh_mera = datetime.strftime(starting_date, "%d/%m/%Y")
        output_date = starting_date + timedelta(days=5 * 30)
        ending_date = datetime.strftime(output_date, "%d/%m/%Y")  # telikh hmerominia se dateformat
        aksia += cumulativevalue[j]
        limit_month += 1

        if output_date.date() >= datelimit.date():  # exoyme kseperasei tin teleutaia hmerominia toy array
            output_date = datelimit  # vazoyme tin teleutaia mera ish me to teleutaio date date
            ending_date = datetime.strftime(output_date, "%d/%m/%Y")
            flag = 1  # flag gia na spasei to loop
        if limit_month == 150 or flag == 1:  # enas counter poy metraei poses meres exoyn perasei poy exoyme prosthesei
            temp_date = [telikh_arxikh_mera + "-" + ending_date,
                         aksia]  # vazoyme tin aksia twn 150 se mia list kai ksekiname apo tin arxi
            final_date_list.append(temp_date)
            aksia = 0
            limit_month = 0
            starting_date = output_date + timedelta(days=1)  # to starting date tha parei tin epomeni mera
        if flag == 1:
            break

    count = len(final_date_list)

    dates = [final_date_list[k][0] for k in range(count)]
    values = [final_date_list[k][1] for k in range(count)]

    fig, ax = plt.subplots()

    x = range(len(dates))
    ax.bar(x, values)
    ax.set_xticks(x)
    ax.set_xticklabels(dates)

    ax.set_title('Cumulative value per 5 months')

    plt.show()

    if flag == 1:
        sys.exit()


def largestrevenuebyproduct(cumulativevalue, commodity, rownumber, countrylist):
    unique_product_set = set(commodity)
    unique_product_list=list(unique_product_set)
    prod_num = len(unique_product_list)  # arithmos twn products poy yparxoyn

    counter = 0
    k=0

    unique_country_set = set(countrylist)
    unique_country_list=list(unique_country_set)
    country_num = len(unique_country_list)

    result = []
    for i in range(country_num):
        element = [unique_country_list[i], unique_product_list,0]
        result.append(element)
    print(result)






CSV_URL = 'https://www.stats.govt.nz/assets/Uploads/Effects-of-COVID-19-on-trade/Effects-of-COVID-19-on-trade-At-15-December-2021-provisional/Download-data/effects-of-covid-19-on-trade-at-15-december-2021-provisional.csv'


# katevazei to csv apo to internet anti na einai hdh katevasmeno ston ypologisth se kapoio file me vash to url poy
# toy dineis
def ValueByCountry(datavalue, datacountry, datarowsnumber, measurelist):
    countryoccurencelist = set(datacountry)  # monadika ids twn countries stin uniquecountries
    uniquecountries = (list(countryoccurencelist))

    countriescount = len(uniquecountries)
    countryvaluearray = [[0 for _ in range(2)] for _ in
                         range(countriescount)]  # eixa provlhma me to overflow me to numpy kathws ta interger toy numpy
    # np.zeros(dimensions, int, 'C')                                    #einai 64 bit enw kanonika h python "den exei" orio sta int. Ara to ekana alliws

    for i in range(datarowsnumber - 1):
        for k in range(countriescount):
            if uniquecountries[k] == datacountry[i]:  # vriskei tin xwra kai to noumero tis stin lista uniquecountries
                if measurelist[i] == '$':
                    countryvaluearray[k][0] += datavalue[i]
                else:
                    countryvaluearray[k][1] += datavalue[i]

    colors = ['red', 'blue', 'green', 'yellow', 'orange', 'black', 'purple', 'cyan', 'pink']

    dollar = [countryvaluearray[k][0] for k in range(countriescount)]
    tonnes = [countryvaluearray[k][1] for k in range(countriescount)]

    plt.subplot(1, 2, 1)
    plt.pie(dollar, labels=uniquecountries, colors=colors, autopct='%1.1f%%')
    plt.title("Total Dollar Value by Country")

    plt.subplot(1, 2, 2)
    plt.pie(tonnes, labels=uniquecountries, colors=colors, autopct='%1.1f%%')
    plt.title("Total Tonnes Value by Country")

    plt.show()


yes_string = 'yes'
no_string = 'no'
option = ''

with requests.Session() as s:  # kanei download to file poy dinetai sto url
    download_csv = s.get(CSV_URL)

    decoded_content = download_csv.content.decode('utf-8')  # kanei decode ta dedomena me vash to utf-8

    cr = csv.reader(decoded_content.splitlines(), delimiter=',')
    data = list(cr)  # vazei ola ta data se mia list poy apoteleitai apo mia lista gia kathe grammh

    while option != yes_string and option != no_string:  # kanei print olo to dataset ama to epithumei o user
        option = input("Would you like the data printed?yes/no\n")
        if option == yes_string:
            for x in data:
                print(x)

# data[0] einai ta titles,ksekiname apo to data[1] gia tin lista1 poy einai grammh 1 ktlp

# gia tin sthlh value tha einai data[i][8] gia oso einai to i

Datalistlength = len(data)  # 111439 edw -- 111438 me data
# 0 Direction
# 1 Year
# 2 Date
# 3 Weekday
# 4 Country
# 5 Commodity
# 6 Transport_Mode
# 7 Measure
# 8 Value
# 9 Cumulative

# tha ftiaksw 1-D lists poy tha periexoyn ta antistoixa columns apo to csv gia to kathe title
DirectionList = list()
YearList = list()
DateList = list()
WeekList = list()
CountryList = list()
CommodityList = list()
Transport_ModeList = list()
MeasureList = list()
ValueListTemp = list()
CumulativeListTemp = list()

ListCreation(data, 0, Datalistlength, DirectionList)
ListCreation(data, 1, Datalistlength, YearList)
ListCreation(data, 2, Datalistlength, DateList)
ListCreation(data, 3, Datalistlength, WeekList)
ListCreation(data, 4, Datalistlength, CountryList)
ListCreation(data, 5, Datalistlength, CommodityList)
ListCreation(data, 6, Datalistlength, Transport_ModeList)
ListCreation(data, 7, Datalistlength, MeasureList)
ListCreation(data, 8, Datalistlength, ValueListTemp)
ListCreation(data, 9, Datalistlength, CumulativeListTemp)

ValueList = [int(x) for x in ValueListTemp]
CumulativeList = [int(x) for x in CumulativeListTemp]  # metatropi twn string se int listes

# GUI
root = tk.Tk()
root.geometry("1024x658+500+200")
root.title("1084595: GUI for Project")
image = Image.open("globaltrade.png")
photo = ImageTk.PhotoImage(image)
background = tk.Label(root, image=photo)
background.place(x=0, y=0, relwidth=1, relheight=1)
titlos = tk.Label(root, text="Click on of the buttons to display the charts", font=('Arial Black', 15),
                  background='red')

# ftiaxnw ta koumpia
MonthButton = tk.Button(root, text="Value By Month", command=lambda: button_clicked(1), fg='red', bg='black',
                        activebackground='orange', height=2, padx=7)
CountryButton = tk.Button(root, text="Value By Country", command=lambda: button_clicked(2), fg='red', bg='black',
                          activebackground='orange', height=2, padx=3)
TransportButton = tk.Button(root, text="Value By Transport", command=lambda: button_clicked(3), fg='red', bg='black',
                            activebackground='orange', height=2)
WeekButton = tk.Button(root, text="Value By Week", command=lambda: button_clicked(4), fg='red', bg='black',
                       activebackground='orange', height=2, padx=12)
CommodityButton = tk.Button(root, text="Value By Merchandise", command=lambda: button_clicked(5), fg='red', bg='black',
                            activebackground='orange', height=2)
BiggestValue5mo = tk.Button(root, text="Largest cumulative value in 5 months", command=lambda: button_clicked(7),
                            fg='red', bg='black',
                            activebackground='orange', height=2)
revenuebycountry5mo = tk.Button(root, text="Largest 5 cumulative value of commodities by country",
                                command=lambda: button_clicked(8),
                                fg='red', bg='black',
                                activebackground='orange', height=2)
ExitButton = tk.Button(root, text="Exit", command=lambda: button_clicked(6), fg='black', font=('Arial', 12))

ExitButton.place(relx=0.9, rely=0.2)

# Add the buttons to the root window
titlos.pack(pady=15)
MonthButton.pack()
CountryButton.pack()
TransportButton.pack()
WeekButton.pack()
CommodityButton.pack()
BiggestValue5mo.pack()
revenuebycountry5mo.pack()
# Run GUI
root.mainloop()
